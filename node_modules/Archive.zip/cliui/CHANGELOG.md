# Change Log

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

<a name="3.2.0"></a>
# [3.2.0](https://github.com/yargs/cliui/compare/v3.1.2...v3.2.0) (2016-04-11)


### Bug Fixes

* reduces tarball size ([acc6c33](https://github.com/yargs/cliui/commit/acc6c33))

### Features

* adds standard-version for release management ([ff84e32](https://github.com/yargs/cliui/commit/ff84e32))
